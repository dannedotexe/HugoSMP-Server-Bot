SAFE PATCH

Das löscht nichts. Es fügt nur automatisch Features in deine bestehende index.js ein.

Benutzung:
1. patch-index.js in denselben Ordner wie index.js hochladen.
2. Ausführen:
   node patch-index.js
3. index.js prüfen.
4. Commit changes.
5. Railway Redeploy.

Features:
- /giveaway start/end/reroll/manualwinner
- Mindest-Invites
- Ticket-Auswahl: Items und Geld, Schematics, Resource Pack
- Bewertung fragt zusätzlich: Was hast du gekauft?
